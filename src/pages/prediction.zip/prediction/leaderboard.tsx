import PredictionsLeaderboard from '../../views/Predictions/Leaderboard'

export default PredictionsLeaderboard
