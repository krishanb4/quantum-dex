import Predictions from '../../views/Predictions'

export default Predictions
