import { IfoPageLayout } from '../../views/Ifos'
import PastIfo from '../../views/Ifos/PastIfo'

const PastIfoPage = () => {
  return <PastIfo />
}

PastIfoPage.Layout = IfoPageLayout

export default PastIfoPage
